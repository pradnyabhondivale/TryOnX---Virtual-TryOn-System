import { useState } from "react";
import { AnimatePresence } from "framer-motion";
import { BrowserRouter, Routes, Route } from "react-router-dom";

import SplashScreen from "./components/splash/SplashScreen";
import LandingPage from "./pages/LandingPage";
import Login from "./pages/Login";
import Signup from "./pages/Signup";

export default function App() {

  const [loading, setLoading] = useState(true);

  return (
    <BrowserRouter>

      <AnimatePresence mode="wait">

        {loading ? (

          <SplashScreen
            key="splash"
            onFinish={() => setLoading(false)}
          />

        ) : (

          <Routes>

            <Route path="/" element={<LandingPage />} />

            <Route path="/login" element={<Login />} />

            <Route path="/signup" element={<Signup />} />

          </Routes>

        )}

      </AnimatePresence>

    </BrowserRouter>
    
  );
}