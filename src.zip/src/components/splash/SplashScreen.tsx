import { motion } from "framer-motion";
import { useEffect } from "react";
import logo from "../../assets/images/logo.png";

type SplashScreenProps = {
  onFinish: () => void;
};

export default function SplashScreen({ onFinish }: SplashScreenProps) {

  useEffect(() => {
    const timer = setTimeout(() => {
      onFinish();
    }, 3200); // matches animation timing

    return () => clearTimeout(timer);
  }, [onFinish]);

  const tagline = "Virtual Fashion Experience".split("");

  return (
    <motion.div
      className="relative flex flex-col items-center justify-center h-screen bg-black overflow-hidden text-white"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0, scale: 1.05 }}
      transition={{ duration: 0.8 }}
    >

      {/* Purple Glow Background */}
      <div className="absolute w-[700px] h-[700px] bg-purple-700 opacity-30 blur-[200px] rounded-full"></div>

      {/* Floating Sparkles */}
      <div className="absolute inset-0">
        {[...Array(25)].map((_, i) => (
          <motion.span
            key={i}
            className="absolute bg-purple-400 rounded-full"
            style={{
              width: "5px",
              height: "5px",
              top: `${Math.random() * 100}%`,
              left: `${Math.random() * 100}%`
            }}
            animate={{
              y: [0, -25, 0],
              opacity: [0.2, 1, 0.2]
            }}
            transition={{
              duration: 4,
              repeat: Infinity,
              delay: i * 0.3
            }}
          />
        ))}
      </div>

      {/* CIRCLE + LOGO */}
      <div className="relative flex items-center justify-center w-[380px] h-[380px]">

        {/* Orbit Rings */}
        <motion.div
          className="absolute w-[380px] h-[380px] border border-purple-500 rounded-full"
          animate={{ rotate: 360 }}
          transition={{ repeat: Infinity, duration: 20, ease: "linear" }}
        />

        <motion.div
          className="absolute w-[300px] h-[300px] border border-purple-400 rounded-full"
          animate={{ rotate: -360 }}
          transition={{ repeat: Infinity, duration: 14, ease: "linear" }}
        />

        {/* Logo */}
        <motion.img
          src={logo}
          alt="TryOnX"
          className="w-56 z-10 drop-shadow-[0_0_35px_rgba(168,85,247,0.9)]"
          initial={{ scale: 0 }}
          animate={{ scale: 1.15 }}
          transition={{ duration: 1 }}
        />

      </div>

      {/* Animated Tagline */}
      <div className="mt-12 flex flex-col items-center z-10">

        <div
          className="flex flex-wrap justify-center text-4xl font-light tracking-[0.35em] text-purple-300 uppercase"
          style={{ fontFamily: "Poppins, sans-serif" }}
        >
          {tagline.map((letter, index) => (
            <motion.span
              key={index}
              initial={{ opacity: 0, y: 40 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.05 }}
              className="mx-[2px]"
            >
              {letter === " " ? "\u00A0" : letter}
            </motion.span>
          ))}
        </div>

        <motion.div
          className="w-40 h-[2px] bg-gradient-to-r from-transparent via-purple-400 to-transparent mt-4"
          initial={{ scaleX: 0 }}
          animate={{ scaleX: 1 }}
          transition={{ delay: 1.5, duration: 1 }}
        />

        <motion.p
          className="text-purple-200 mt-6 text-lg italic tracking-wide"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 2 }}
          style={{ fontFamily: "Playfair Display, serif" }}
        >
          Discover Your Perfect Look Instantly
        </motion.p>

      </div>

    </motion.div>
  );
}