import { motion } from "framer-motion";
import { useNavigate } from "react-router-dom";
import { useEffect, useRef, useState } from "react";
import {
Sparkles,
Share2,
Scan,
Star,
Shirt,
ShoppingBag,
Zap
} from "lucide-react";


/* ---------------- ANIMATION VARIANTS ---------------- */

const sectionVariant = {
hidden:{opacity:0,y:80},
show:{
opacity:1,
y:0,
transition:{duration:.8}
}
};

const containerVariant = {
hidden:{opacity:0},
show:{
opacity:1,
transition:{staggerChildren:.25}
}
};

const cardVariant = {
hidden:{opacity:0,y:60,scale:.9},
show:{opacity:1,y:0,scale:1}
};


/* ---------------- COUNTER COMPONENT ---------------- */

function AnimatedCounter({value}:{value:number}){

const [count,setCount] = useState(0);
const ref = useRef<HTMLSpanElement | null>(null);
const started = useRef(false);

useEffect(()=>{

const observer = new IntersectionObserver((entries)=>{

if(entries[0].isIntersecting && !started.current){

started.current=true;

let start=0;
const duration=2000;
const increment=value/(duration/16);

const timer=setInterval(()=>{

start+=increment;

if(start>=value){
setCount(value);
clearInterval(timer);
}else{
setCount(Math.floor(start));
}

},16);

}

});

if(ref.current) observer.observe(ref.current);

return()=>observer.disconnect();

},[value]);

return <span ref={ref}>{count.toLocaleString()}</span>;

}


/* ---------------- LANDING PAGE ---------------- */

export default function LandingPage(){

const navigate = useNavigate();

const [mouse,setMouse] = useState({x:0,y:0});

useEffect(()=>{

const move=(e:MouseEvent)=>{
setMouse({x:e.clientX,y:e.clientY});
};

window.addEventListener("mousemove",move);

return()=>window.removeEventListener("mousemove",move);

},[]);


const scrollTo=(id:string)=>{
const section=document.getElementById(id);
if(section) section.scrollIntoView({behavior:"smooth"});
};


const features=[

{
icon:<Scan size={28}/>,
title:"AI Virtual Try-On",
desc:"Upload your photo and preview outfits using AI."
},

{
icon:<Sparkles size={28}/>,
title:"Smart Size Recommendation",
desc:"AI recommends perfect clothing sizes."
},

{
icon:<Share2 size={28}/>,
title:"Save & Share Looks",
desc:"Share outfit previews with friends."
},

{
icon:<ShoppingBag size={28}/>,
title:"Virtual Wardrobe",
desc:"Build and manage your digital wardrobe."
}

];

const testimonials=[

{
text:"This AI try-on changed my online shopping experience.",
name:"Sophia"
},

{
text:"Amazing technology! I can see clothes before buying.",
name:"James"
},

{
text:"Super helpful for online shopping decisions.",
name:"Emma"
},

{
text:"Feels like magic. The fitting prediction is accurate.",
name:"Daniel"
},

{
text:"I love the virtual wardrobe feature.",
name:"Olivia"
}

];


const steps=[

{
icon:<Scan size={30}/>,
title:"Upload Photo",
desc:"Upload your full-body image."
},

{
icon:<Shirt size={30}/>,
title:"Select Outfit",
desc:"Choose clothing from the catalog."
},

{
icon:<Zap size={30}/>,
title:"AI Try-On",
desc:"See realistic outfit preview instantly."
}

];


/* ---------------- JSX ---------------- */

return(

<div className="bg-[#0b0f1a] text-white min-h-screen overflow-x-hidden relative">


{/* CURSOR GLOW */}

<div
className="pointer-events-none fixed w-[400px] h-[400px] rounded-full blur-[120px] opacity-20 bg-purple-500"
style={{
left:mouse.x-200,
top:mouse.y-200
}}
></div>



{/* NAVBAR */}

<nav className="fixed w-full z-50 backdrop-blur-xl bg-black/40 border-b border-purple-900/40">

<div className="max-w-7xl mx-auto flex justify-between items-center px-8 py-5">

<div
onClick={()=>scrollTo("hero")}
className="flex items-center gap-3 cursor-pointer"
>

<img src="/logo.png" className="w-12 h-12"/>

<span className="text-xl font-bold">

<span className="text-purple-400">Try</span>
<span className="text-cyan-400">OnX</span>

</span>

</div>


<div className="hidden md:flex gap-10 text-gray-300">

<button onClick={()=>scrollTo("hero")} className="hover:text-purple-400">
Home
</button>

<button onClick={()=>scrollTo("features")} className="hover:text-purple-400">
Features
</button>

<button onClick={()=>scrollTo("how")} className="hover:text-purple-400">
How It Works
</button>

<button onClick={()=>navigate("/login")} className="hover:text-purple-400">
Login
</button>

</div>

<motion.button
whileHover={{scale:1.05}}
whileTap={{scale:.95}}
onClick={()=>navigate("/signup")}
className="px-6 py-2 rounded-xl bg-gradient-to-r from-purple-500 to-pink-500"
>
Get Started
</motion.button>

</div>

</nav>



{/* HERO */}

<section
id="hero"
className="relative pt-40 pb-36 text-center overflow-hidden"
>

{/* animated gradient background */}

<div className="absolute inset-0 bg-gradient-to-br from-purple-900 via-[#070d1f] to-[#020617]"></div>


{/* glowing blobs */}

<div className="absolute w-[500px] h-[500px] bg-purple-600 opacity-25 blur-[160px] rounded-full top-[-200px] left-[-100px] animate-pulse"></div>

<div className="absolute w-[500px] h-[500px] bg-pink-600 opacity-20 blur-[160px] rounded-full bottom-[-200px] right-[-100px] animate-pulse"></div>



{/* floating icons */}

<motion.div
animate={{ y:[0,-25,0] }}
transition={{ repeat:Infinity, duration:6 }}
className="absolute left-16 top-40 text-purple-400 opacity-70"
>
<Shirt size={52}/>
</motion.div>

<motion.div
animate={{ y:[0,20,0] }}
transition={{ repeat:Infinity, duration:7 }}
className="absolute right-16 top-56 text-cyan-400 opacity-70"
>
<ShoppingBag size={52}/>
</motion.div>



<div className="relative max-w-5xl mx-auto px-6">

{/* AI badge */}

<motion.div
initial={{opacity:0,y:10}}
animate={{opacity:1,y:0}}
transition={{duration:.6}}
className="inline-block mb-6 px-4 py-1 text-sm rounded-full bg-purple-500/20 border border-purple-400 text-purple-300"
>

AI Powered Virtual Try-On

</motion.div>


{/* title */}

<motion.h1
initial={{opacity:0,y:40}}
animate={{opacity:1,y:0}}
transition={{duration:1}}
className="text-6xl md:text-7xl font-bold leading-tight"
>

The Future of <br/>

<span className="bg-gradient-to-r from-purple-400 via-pink-400 to-cyan-400 text-transparent bg-clip-text">

Virtual Fashion

</span>

</motion.h1>



{/* subtitle */}

<motion.p
initial={{opacity:0,y:20}}
animate={{opacity:1,y:0}}
transition={{delay:.3}}
className="mt-6 text-gray-400 text-lg max-w-xl mx-auto"
>

Try clothes virtually using AI before buying online.

</motion.p>



{/* buttons */}

<div className="mt-10 flex justify-center gap-6">

<motion.button
whileHover={{scale:1.1}}
whileTap={{scale:.95}}
onClick={()=>navigate("/signup")}
className="px-10 py-4 rounded-xl bg-gradient-to-r from-purple-500 to-pink-500 shadow-[0_0_30px_rgba(168,85,247,.6)]"
>

Start Try-On

</motion.button>


<motion.button
whileHover={{scale:1.05}}
onClick={()=>scrollTo("features")}
className="px-10 py-4 rounded-xl border border-gray-600 backdrop-blur-lg"
>

Explore Features

</motion.button>

</div>

</div>



{/* floating preview cards */}

<motion.div
animate={{ y:[0,-20,0] }}
transition={{repeat:Infinity,duration:8}}
className="hidden lg:block absolute left-40 bottom-10 p-4 rounded-xl bg-white/5 backdrop-blur-lg border border-white/10"
>

<p className="text-sm text-gray-300">
👕 Outfit Preview
</p>

</motion.div>


<motion.div
animate={{ y:[0,20,0] }}
transition={{repeat:Infinity,duration:9}}
className="hidden lg:block absolute right-40 bottom-16 p-4 rounded-xl bg-white/5 backdrop-blur-lg border border-white/10"
>

<p className="text-sm text-gray-300">
✨ AI Fit Prediction
</p>

</motion.div>

</section>


{/* STATS */}

<section className="py-20 border-y border-gray-800">

<div className="max-w-6xl mx-auto grid grid-cols-1 md:grid-cols-3 text-center gap-12">

<div>

<h2 className="text-4xl font-bold text-purple-400">
<AnimatedCounter value={50000}/>+
</h2>

<p className="text-gray-400 mt-2 text-sm">
Virtual Try-Ons
</p>

</div>

<div>

<h2 className="text-4xl font-bold text-purple-400">
<AnimatedCounter value={10000}/>+
</h2>

<p className="text-gray-400 mt-2 text-sm">
Active Users
</p>

</div>

<div>

<h2 className="text-4xl font-bold text-purple-400">
<AnimatedCounter value={500}/>+
</h2>

<p className="text-gray-400 mt-2 text-sm">
Fashion Brands
</p>

</div>

</div>

</section>


{/* FEATURES */}

<section id="features" className="py-24 md:py-40">

<motion.h2
variants={sectionVariant}
initial="hidden"
whileInView="show"
viewport={{once:true}}
className="text-center text-5xl font-bold mb-20"
>
Powerful AI Features
</motion.h2>


<motion.div
variants={containerVariant}
initial="hidden"
whileInView="show"
viewport={{once:true}}
className="max-w-7xl mx-auto grid md:grid-cols-2 lg:grid-cols-4 gap-10 px-8"
>

{features.map((f,i)=>(

<motion.div
key={i}
variants={cardVariant}
whileHover={{y:-10,scale:1.05}}
className="p-10 rounded-2xl backdrop-blur-xl bg-white/5 border border-white/10"
>

<div className="w-14 h-14 rounded-lg bg-purple-600 flex items-center justify-center mb-6">
{f.icon}
</div>

<h3 className="text-xl font-semibold mb-3">
{f.title}
</h3>

<p className="text-gray-400">
{f.desc}
</p>

</motion.div>

))}

</motion.div>

</section>



{/* HOW IT WORKS */}

<section id="how" className="py-24 md:py-40 bg-[#0d1323]">

<motion.h2
variants={sectionVariant}
initial="hidden"
whileInView="show"
viewport={{once:true}}
className="text-center text-5xl font-bold mb-20"
>
How It Works
</motion.h2>

<motion.div
variants={containerVariant}
initial="hidden"
whileInView="show"
viewport={{once:true}}
className="max-w-6xl mx-auto grid md:grid-cols-3 gap-12 px-6"
>

{steps.map((step,i)=>(

<motion.div
key={i}
variants={cardVariant}
whileHover={{scale:1.05,y:-8}}
className="p-10 rounded-xl bg-[#111827] border border-gray-800"
>

<div className="flex justify-center mb-6 text-purple-400">
{step.icon}
</div>

<h3 className="text-xl font-semibold mb-3">
{step.title}
</h3>

<p className="text-gray-400">
{step.desc}
</p>

</motion.div>

))}

</motion.div>

</section>



{/* TESTIMONIALS */}

<section className="py-32 overflow-hidden">

<h2 className="text-center text-5xl font-bold mb-20">
Loved by Fashion Enthusiasts
</h2>

<motion.div
animate={{x:["0%","-50%"]}}
transition={{
repeat:Infinity,
duration:25,
ease:"linear"
}}
className="flex gap-10 w-max"
>

{[...testimonials,...testimonials].map((t,i)=>(

<div
key={i}
className="p-8 w-[320px] rounded-xl bg-[#111827] border border-gray-800"
>

<p className="text-gray-400 mb-4">
"{t.text}"
</p>

<div className="flex text-yellow-400 mb-3">
<Star/><Star/><Star/><Star/><Star/>
</div>

<h4 className="font-semibold">
{t.name}
</h4>

</div>

))}

</motion.div>

</section>



 {/* CTA */}

<section className="py-20 text-center bg-gradient-to-r from-purple-900 to-black">

<h2 className="text-5xl font-bold mb-6">
Start Your Virtual Try-On Journey
</h2>

<p className="text-gray-300 mb-10">
Join thousands of users already using TryOnX
</p>

<motion.button
whileHover={{scale:1.1}}
whileTap={{scale:.95}}
onClick={()=>navigate("/signup")}
className="px-12 py-4 rounded-xl bg-gradient-to-r from-purple-500 to-pink-500"
>

Create Free Account

</motion.button>

</section>



{/* FOOTER */}

<footer className="py-10 border-t border-gray-800 text-center text-gray-500">

<div className="text-lg font-bold mb-2">
TryOnX
</div>

<p>AI Powered Virtual Fashion Platform</p>

<p className="mt-6 text-sm">
© 2026 TryOnX
</p>

</footer>


</div>

);

}

