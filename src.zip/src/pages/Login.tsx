import { useState } from "react";
import { motion } from "framer-motion";
import { Eye, EyeOff, Mail, Lock } from "lucide-react";
import { Link } from "react-router-dom";

export default function Login() {

const [showPassword,setShowPassword] = useState(false);

return (

<div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-[#0b0f1a] via-[#111827] to-black text-white relative overflow-hidden">

{/* background glow */}

<div className="absolute w-[500px] h-[500px] bg-purple-700/20 blur-[120px] rounded-full -top-40 -left-40"></div>
<div className="absolute w-[500px] h-[500px] bg-pink-700/20 blur-[120px] rounded-full -bottom-40 -right-40"></div>

<motion.div
initial={{ opacity:0, y:30 }}
animate={{ opacity:1, y:0 }}
transition={{ duration:.6 }}
className="w-[380px] backdrop-blur-xl bg-white/5 border border-purple-900 rounded-2xl p-10 shadow-xl"
>

<h2 className="text-3xl font-bold text-center mb-8">

<span className="text-purple-400">Try</span>
<span className="text-cyan-400">OnX</span>

</h2>


{/* EMAIL */}

<div className="relative mb-5">

<Mail className="absolute left-3 top-3 text-gray-400" size={18}/>

<input
type="email"
placeholder="Email address"
className="w-full pl-10 pr-4 py-3 rounded-lg bg-black/40 border border-gray-700 focus:border-purple-500 outline-none"
/>

</div>


{/* PASSWORD */}

<div className="relative mb-6">

<Lock className="absolute left-3 top-3 text-gray-400" size={18}/>

<input
type={showPassword ? "text":"password"}
placeholder="Password"
className="w-full pl-10 pr-10 py-3 rounded-lg bg-black/40 border border-gray-700 focus:border-purple-500 outline-none"
/>

<button
type="button"
onClick={()=>setShowPassword(!showPassword)}
className="absolute right-3 top-3 text-gray-400"
>
{showPassword ? <EyeOff size={18}/> : <Eye size={18}/>}
</button>

</div>


{/* LOGIN BUTTON */}

<motion.button
whileHover={{ scale:1.05 }}
whileTap={{ scale:.95 }}
className="w-full py-3 rounded-lg bg-gradient-to-r from-purple-500 to-pink-500 shadow-lg shadow-purple-900 hover:shadow-purple-600 transition"
>

Login

</motion.button>


{/* SIGNUP LINK */}

<p className="text-gray-400 text-center mt-6">

Don't have an account?{" "}

<Link
to="/signup"
className="text-purple-400 hover:text-purple-300"
>

Sign Up

</Link>

</p>

</motion.div>

</div>

);

}