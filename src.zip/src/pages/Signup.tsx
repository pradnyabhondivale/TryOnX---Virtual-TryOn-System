import {
createUserWithEmailAndPassword,
GoogleAuthProvider,
signInWithPopup
} from "firebase/auth";

import { setDoc, doc } from "firebase/firestore";
import { auth, db } from "../firebase";

import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";

import {
Eye,
EyeOff,
Mail,
Lock,
User
} from "lucide-react";

import { Link, useNavigate } from "react-router-dom";

export default function Signup(){

const navigate = useNavigate();

const [showPassword,setShowPassword]=useState(false);
const [showConfirm,setShowConfirm]=useState(false);

const [name,setName]=useState("");
const [email,setEmail]=useState("");
const [password,setPassword]=useState("");
const [confirmPassword,setConfirmPassword]=useState("");

const [loading,setLoading]=useState(false);
const [success,setSuccess]=useState(false);

/* PASSWORD STRENGTH */

const passwordStrength=()=>{

if(password.length>10) return "Strong";
if(password.length>6) return "Medium";
if(password.length>0) return "Weak";

return "";

};

/* EMAIL SIGNUP */

const signupUser = async () => {

if(!name || !email || !password){
alert("Please fill all fields");
return;
}

if(password !== confirmPassword){
alert("Passwords do not match");
return;
}

try{

setLoading(true);

const userCredential = await createUserWithEmailAndPassword(
auth,
email,
password
);

const user = userCredential.user;

await setDoc(doc(db,"users",user.uid),{
name:name,
email:email,
createdAt:new Date()
});

/* STOP LOADING */

setLoading(false);

/* SHOW POPUP */

setSuccess(true);

/* REDIRECT AFTER 2.5s */

setTimeout(()=>{
navigate("/login");
},2500);

}catch(err:any){

setLoading(false);
alert(err.message);

}

};

/* GOOGLE SIGNUP */

const googleSignup = async () => {

try{

const provider = new GoogleAuthProvider();

/* FORCE ACCOUNT SELECT */

provider.setCustomParameters({
prompt:"select_account"
});

const result = await signInWithPopup(auth,provider);

const user = result.user;

await setDoc(doc(db,"users",user.uid),{
name:user.displayName,
email:user.email,
photo:user.photoURL,
createdAt:new Date()
},{merge:true});

navigate("/dashboard");

}catch(err:any){

console.log(err);
alert("Google signup failed");

}

};

return(

<div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-[#0b0f1a] via-[#111827] to-black text-white relative overflow-hidden">

{/* SUCCESS POPUP */}

<AnimatePresence>

{success && (

<motion.div
initial={{opacity:0,scale:0.8}}
animate={{opacity:1,scale:1}}
exit={{opacity:0}}
className="absolute top-10 bg-green-500 text-black px-6 py-3 rounded-lg shadow-lg font-medium z-50"
>

🎉 {name}, your account was created successfully!

</motion.div>

)}

</AnimatePresence>

{/* BACKGROUND LIGHTS */}

<div className="absolute w-[600px] h-[600px] bg-purple-700/20 blur-[140px] rounded-full -top-40 -left-40"></div>
<div className="absolute w-[600px] h-[600px] bg-cyan-700/20 blur-[140px] rounded-full -bottom-40 -right-40"></div>

<motion.div
initial={{opacity:0,y:40}}
animate={{opacity:1,y:0}}
transition={{duration:.6}}
className="w-[440px] backdrop-blur-xl bg-white/5 border border-purple-900/40 rounded-2xl p-10 shadow-2xl"
>

<h2 className="text-3xl font-bold text-center mb-2">
Create your account
</h2>

<p className="text-gray-400 text-center mb-8 text-sm">
Start your AI virtual try-on experience
</p>

{/* GOOGLE SIGNUP */}

<motion.button
onClick={googleSignup}
whileHover={{scale:1.03}}
whileTap={{scale:.97}}
className="w-full flex items-center justify-center gap-3 py-3 rounded-lg bg-white text-black font-medium mb-6"
>

<img
src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/google/google-original.svg"
className="w-5"
/>

Continue with Google

</motion.button>

{/* DIVIDER */}

<div className="flex items-center gap-4 my-6">
<div className="flex-1 h-px bg-gray-700"></div>
<span className="text-gray-400 text-sm">
or sign up with email
</span>
<div className="flex-1 h-px bg-gray-700"></div>
</div>

{/* NAME */}

<div className="relative mb-4">

<User className="absolute left-3 top-3 text-gray-400" size={18}/>

<input
type="text"
placeholder="Full Name"
value={name}
onChange={(e)=>setName(e.target.value)}
className="w-full pl-10 pr-4 py-3 rounded-lg bg-black/40 border border-gray-700"
/>

</div>

{/* EMAIL */}

<div className="relative mb-4">

<Mail className="absolute left-3 top-3 text-gray-400" size={18}/>

<input
type="email"
placeholder="Email address"
value={email}
onChange={(e)=>setEmail(e.target.value)}
className="w-full pl-10 pr-4 py-3 rounded-lg bg-black/40 border border-gray-700"
/>

</div>

{/* PASSWORD */}

<div className="relative mb-2">

<Lock className="absolute left-3 top-3 text-gray-400" size={18}/>

<input
type={showPassword?"text":"password"}
placeholder="Password"
value={password}
onChange={(e)=>setPassword(e.target.value)}
className="w-full pl-10 pr-10 py-3 rounded-lg bg-black/40 border border-gray-700"
/>

<button
type="button"
onClick={()=>setShowPassword(!showPassword)}
className="absolute right-3 top-3 text-gray-400"
>

{showPassword ? <EyeOff size={18}/> : <Eye size={18}/>}

</button>

</div>

{/* PASSWORD STRENGTH */}

{password && (

<p className={`text-xs mb-4 ${
passwordStrength()==="Strong"
? "text-green-400"
: passwordStrength()==="Medium"
? "text-yellow-400"
: "text-red-400"
}`}>

Password strength: {passwordStrength()}

</p>

)}

{/* CONFIRM PASSWORD */}

<div className="relative mb-6">

<Lock className="absolute left-3 top-3 text-gray-400" size={18}/>

<input
type={showConfirm?"text":"password"}
placeholder="Confirm Password"
value={confirmPassword}
onChange={(e)=>setConfirmPassword(e.target.value)}
className="w-full pl-10 pr-10 py-3 rounded-lg bg-black/40 border border-gray-700"
/>

<button
type="button"
onClick={()=>setShowConfirm(!showConfirm)}
className="absolute right-3 top-3 text-gray-400"
>

{showConfirm ? <EyeOff size={18}/> : <Eye size={18}/>}

</button>

</div>

{/* SIGNUP BUTTON */}

<motion.button
onClick={signupUser}
disabled={loading}
whileHover={{scale:1.05}}
whileTap={{scale:.95}}
className="w-full py-3 rounded-lg bg-gradient-to-r from-purple-500 to-cyan-500 font-medium"
>

{loading ? "Creating..." : "Create Account"}

</motion.button>

<p className="text-gray-400 text-center mt-6 text-sm">

Already have an account?{" "}

<Link
to="/login"
className="text-purple-400 hover:text-purple-300"
>

Login

</Link>

</p>

</motion.div>

</div>

);

}